package data.programming.students;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class StudentsAPIController {

        @GetMapping(value = {"/getstudents", "/getstudents/{id}"})
        public List<Object[]> getStudents(@PathVariable(required = false) Integer id) {

            List<Object[]> students = new ArrayList<>();

            students.add(new Object[] {1, "Akif", 30});
            students.add(new Object[] {2, "John", 40});
            students.add(new Object[] {3, "Doe", 35});
            students.add(new Object[] {4, "Jack", 50});

            if (id != null) {
                for (Object[] student: students) {
                    if (id == (int) student[0]) {
                        List<Object[]> result = new ArrayList<>();
                        result.add(student);
                        return result;
                    }
                }
            }

            return students;

        }

        @PostMapping("/addstudent")
        public Map<String, String> addStudent(String studentName, String studentID) {
            HashMap<String, String> map = new HashMap<>();
            map.put("studentName", studentName);
            map.put("studentID", studentID);

            return map;
        }

        @DeleteMapping("/deletestudent")
        public String deleteStudent() {
            return "This is a DELETE REQUEST";
        }

        @PutMapping("/updatestudent/{id}")
        public String updateStudent(@PathVariable Integer id, String studentName, String studentID) {
            return "This is a PUT REQUEST for ID: " + id + " and studentName: " + studentName + " and studentID: " + studentID;
        }

}
