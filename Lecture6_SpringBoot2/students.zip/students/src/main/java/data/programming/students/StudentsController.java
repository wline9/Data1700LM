package data.programming.students;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class StudentsController {

    @GetMapping("/students")
    public String listStudents(Model object) {

        List<Object[]> students = new ArrayList<>();

        students.add(new Object[] {1, "Akif", 30});
        students.add(new Object[] {2, "John", 40});
        students.add(new Object[] {3, "Doe", 35});

        object.addAttribute("name", "John Doe");
        object.addAttribute("students", students);

        return "students";
    }
}
