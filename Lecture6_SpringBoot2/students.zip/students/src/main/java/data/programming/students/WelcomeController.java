package data.programming.students;

import ch.qos.logback.core.util.StringUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/welcome")
public class WelcomeController {

    @GetMapping
    @ResponseBody
    private String sayWelcome(@RequestParam(value = "name", required = false) String name) {

        if (StringUtil.isNullOrEmpty(name)) {
            return "<h1>Welcome anonymous user</h1>";
        } else {
            return "<h1>Welcome " + name + "</h1>";
        }
    }
}
