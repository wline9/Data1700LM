package data.programming.students;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class APIController {

    @GetMapping("/api/greeting")
    public String getGreeting() {
        return "Hello, API World!";
    }

    @GetMapping("/users")
    public List<String> getUsers() {
        return List.of("Alice", "Bob", "Charlie");
    }

    @PostMapping("/users")
    public String createUser(String user) {
        return "User created: " + user;
    }

    @PutMapping("/users/{id}")
    public String updateUser(@PathVariable int id, String user) {
        return "User with ID " + id + " updated to: " + user;
    }

    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable int id) {
        return "User with ID " + id + " deleted.";
    }


}
