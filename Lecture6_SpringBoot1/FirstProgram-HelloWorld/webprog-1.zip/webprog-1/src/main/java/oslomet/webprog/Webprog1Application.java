package oslomet.webprog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webprog1Application {

    public static void main(String[] args) {
        SpringApplication.run(Webprog1Application.class, args);
    }

}
